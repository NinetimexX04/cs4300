import numpy as np

def average(nums):
    arr = np.array(nums)
    return arr.mean()
