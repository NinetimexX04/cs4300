an_int = 42
a_float = 3.14
a_string = "cs4300"
a_bool = True
