def hello():
    return "Hello, World!"

print(hello())
