from src.task1 import hello

def test_hello_world():
    assert hello() == "Hello, World!"
