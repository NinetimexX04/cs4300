from src import task2

def test_types():
    assert isinstance(task2.an_int, int)
    assert isinstance(task2.a_float, float)
    assert isinstance(task2.a_string, str)
    assert isinstance(task2.a_bool, bool)