from src.task7 import average

def test_average():
    assert average([1, 2, 3, 4]) == 2.5